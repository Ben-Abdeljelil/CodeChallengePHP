<?php
    include '../database/databaseConnection.php';

    $connection = OpenDBconnection();

    $filedata = file_get_contents('../database/events.json');     
    $events = json_decode($filedata);
    $errorMessage = "";
    foreach ($events as $event) {
        $event_id = null;
        $employee_id = null;
        $event_exist = "SELECT id FROM events WHERE name = '$event->event_name'";
        if ($connection->query($event_exist)->num_rows == 0) {
            $insert_event_sql = "INSERT INTO events (name, date) VALUES ('$event->event_name', '$event->event_date')";
            if ($connection->query($insert_event_sql) === TRUE) {
                $event_id = $connection->insert_id;
            } else {
                $errorMessage .= "<br> Error: " . $insert_event_sql . "<br>" . $connection->error;
            }
        } else {
            $res = $connection->query($event_exist)->fetch_assoc();
            $event_id = $res['id'];
        }
        $employee_exist = "SELECT id FROM employees WHERE email = '$event->employee_mail'";
        if ($connection->query($employee_exist)->num_rows == 0) {
            $insert_employee_sql = "INSERT INTO employees (name, email) VALUES ('$event->employee_name', '$event->employee_mail')";
            if ($connection->query($insert_employee_sql) === TRUE) {
                $employee_id = $connection->insert_id;
            } else {
                $errorMessage .= "<br> Error: " . $insert_employee_sql . "<br>" . $connection->error;
            }
        } else {
            $res = $connection->query($employee_exist)->fetch_assoc();
            $employee_id = $res['id'];
        }
        if ($event_id !== null && $employee_id !== null) {
            $participation_exist = "SELECT id FROM participations WHERE event_id = $event_id and employee_id = $employee_id";
            if ($connection->query($participation_exist)->num_rows == 0) {
                $fee = isset($event->participation_fee) ? $event->participation_fee : "0";
                $version = isset($event->version) ? $event->version : 'NULL';
                $insert_participation_sql = "INSERT INTO participations (fee, version, event_id, employee_id) VALUES ('$fee', '$version', $event_id, $employee_id)";
                if ($connection->query($insert_participation_sql) !== TRUE) {
                    $errorMessage .= "<br> Error: " . $insert_participation_sql . "<br>" . $connection->error;
                }
            }
        }
    }
    if (empty($errorMessage)) {
        echo "Events data successfully set into database!";
    }
?>