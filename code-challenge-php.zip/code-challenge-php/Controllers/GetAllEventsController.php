<?php
    function getAllEvents() {
        include '../database/databaseConnection.php';
        $connection = OpenDBconnection();
        $events_data = [];
        $totalPrice = 0;
        $all_events_sql = "SELECT participations.id as participation_id, employees.name as employee_name,
                employees.email as employee_mail, events.id as event_id, events.name as event_name,
                participations.fee as participation_fee, events.date as event_date, participations.version
            FROM events left join participations ON events.id = participations.event_id
                left join employees ON employees.id = participations.employee_id
            ORDER BY participations.id";
        $result = $connection->query($all_events_sql);
        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                array_push($events_data, $row);
            }
        }
        if ($events_data) {
            foreach ($events_data as $item) {
                if (isset($item['participation_fee'])) {
                    $totalPrice += floatval($item['participation_fee']);
                }
            }
        }

        return [
            "data" => $events_data,
            "totalPrice" => $totalPrice
        ];
    }
?>