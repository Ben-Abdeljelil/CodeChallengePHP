<?php
    include '../database/databaseConnection.php';
    $connection = OpenDBconnection();
    $events_data = [];
    $totalPrice = 0;
    $filter_events_sql = "SELECT participations.id as participation_id, employees.name as employee_name,
            employees.email as employee_mail, events.id as event_id, events.name as event_name,
            participations.fee as participation_fee, events.date as event_date, participations.version
        FROM events left join participations ON events.id = participations.event_id
            left join employees ON employees.id = participations.employee_id";
    //Employee name
    if (!empty($_REQUEST['employeeName'])) {
        $filter_events_sql .= " WHERE employees.name like '%". $_REQUEST['employeeName'] ."%'";
    }

    //Events name
    if (!empty($_REQUEST['employeeName']) && !empty($_REQUEST['eventName'])) {
        $filter_events_sql .= " and events.name like '%". $_REQUEST['eventName'] ."%'";
    } else if (empty($_REQUEST['employeeName']) &&!empty($_REQUEST['eventName'])) {
        $filter_events_sql .= " WHERE events.name like '%". $_REQUEST['eventName'] ."%'";
    }

    //Events date
    if (( !empty($_REQUEST['employeeName']) || !empty($_REQUEST['eventName'])) && 
        !empty($_REQUEST['eventDate'])
    ) {
        $filter_events_sql .= " and events.date like '%". $_REQUEST['eventDate'] ."%'";
    } else if (
        empty($_REQUEST['employeeName']) && 
        empty($_REQUEST['eventName']) && 
        !empty($_REQUEST['eventDate'])
    ) {
        $filter_events_sql .= " WHERE events.date like '%". $_REQUEST['eventDate'] ."%'";
    }
    
    $filter_events_sql .= " ORDER BY participations.id";
    $result = $connection->query($filter_events_sql);
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            array_push($events_data, $row);
        }
    }
    if ($events_data) {
        foreach ($events_data as $item) {
            if (isset($item['participation_fee'])) {
                $totalPrice += floatval($item['participation_fee']);
            }
        }
    }
    echo json_encode(["data" => $events_data,"totalPrice" => $totalPrice]);
?>