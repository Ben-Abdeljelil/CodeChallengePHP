<?php

function OpenDBconnection()
{
    $db_host      = 'localhost';
    $db_username  = 'root';
    $db_password  = '';
    $db_database  = 'code-challenge-php'; 
    $db_port      = '3307';
    
    $dbConnection = new mysqli($db_host, $db_username, $db_password, $db_database, $db_port) or die("Connect failed: %s\n". $dbConnection->error);
    
    if ($dbConnection->connect_error) {
        die("Connection failed: " . $dbConnection->connect_error);
    }
    return $dbConnection;
}

function CloseDBConnection($dbConnection)
{
    $dbConnection->close();
}
   
?>